const settings = {
  ownerName: 'NamaOwnerLu', // Ganti dengan nama owner lu
  botToken: '7111734303:AAEG_o72rnOChD4m0DWpCOdmsi58KuZXN_A', // Ganti dengan token bot Telegram lu
  owner: '1908668826', //OWNER user id
};

module.exports = settings;
