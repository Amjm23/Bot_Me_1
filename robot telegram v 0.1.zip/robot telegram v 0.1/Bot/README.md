a telegram bot thats can run a various attack methods in your terminal(termux, vps, & pterodactyl)
